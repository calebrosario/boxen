# Nike+ Connect Puppet Module for Boxen

[![Build Status](https://travis-ci.org/bdossantos/puppet-module-nike_plus_connect.png?branch=master)](https://travis-ci.org/bdossantos/puppet-module-nike_plus_connect)

## Usage

```puppet
include nike_plus_connect
```

## Required Puppet Modules

None.
